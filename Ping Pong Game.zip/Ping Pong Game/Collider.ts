namespace PingPongGame{
    export class Collider {
                
    }
}